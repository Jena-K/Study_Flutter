# flutter_toggle_buttons

A demo of the new ToggleButtons segmented button bar widget.

<img src='readme/demo.gif' />